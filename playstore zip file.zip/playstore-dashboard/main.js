// ============================================================
//  PlayStore Analytics v2 — Main JS
// ============================================================

document.addEventListener('DOMContentLoaded', () => {

  // ---- Navigation ----
  const navItems  = document.querySelectorAll('.nav-item[data-section]');
  const sections  = document.querySelectorAll('.section');

  window.switchSection = function(target) {
    sections.forEach(s => s.classList.remove('active'));
    navItems.forEach(n => n.classList.remove('active'));
    const sec = document.getElementById(target);
    if (sec) sec.classList.add('active');
    const nav = document.querySelector(`.nav-item[data-section="${target}"]`);
    if (nav) nav.classList.add('active');
    if (window.innerWidth < 680) {
      document.getElementById('sidebar').classList.remove('open');
    }
    // Lazy-render explorer chart when tab opens
    if (target === 'explorer' && !window._explorerInit) {
      window._explorerInit = true;
      renderExplorer();
    }
  };

  navItems.forEach(item => {
    item.addEventListener('click', e => {
      e.preventDefault();
      switchSection(item.dataset.section);
    });
  });

  // ---- Mobile Menu ----
  const menuToggle = document.getElementById('menuToggle');
  const sidebar    = document.getElementById('sidebar');
  if (menuToggle) {
    menuToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
  }
  document.addEventListener('click', e => {
    if (window.innerWidth < 680 && sidebar.classList.contains('open') &&
        !sidebar.contains(e.target) && e.target !== menuToggle) {
      sidebar.classList.remove('open');
    }
  });

  // ---- Animated Counters ----
  function animateCounter(el) {
    const target = parseInt(el.dataset.target, 10);
    const dur = 1800;
    const start = performance.now();
    function update(now) {
      const pct = Math.min((now - start) / dur, 1);
      const ease = 1 - Math.pow(1 - pct, 3);
      el.textContent = Math.floor(ease * target).toLocaleString();
      if (pct < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }

  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { animateCounter(e.target); io.unobserve(e.target); }
    });
  }, { threshold: 0.5 });
  document.querySelectorAll('.counter').forEach(c => io.observe(c));

  // ---- Category Table (with pagination) ----
  let catSortKey = 'count';
  let catSortDir = -1;
  let catPage    = 1;
  const catPerPage = 10;

  window.sortTable = function(key) {
    if (catSortKey === key) catSortDir *= -1;
    else { catSortKey = key; catSortDir = -1; }
    catPage = 1;
    buildCategoryTable(document.getElementById('catSearch')?.value || '');
  };

  function buildCategoryTable(filter = '') {
    const tbody = document.querySelector('#categoryTable tbody');
    if (!tbody) return;
    const total = PLAYSTORE_DATA.categories.reduce((a, c) => a + c.count, 0);
    let data = PLAYSTORE_DATA.categories
      .filter(c => c.name.toLowerCase().includes(filter.toLowerCase()))
      .map((c, i) => ({ ...c, originalIndex: i + 1 }));

    // Sort
    data.sort((a, b) => {
      if (catSortKey === 'name')  return catSortDir * a.name.localeCompare(b.name);
      if (catSortKey === 'count') return catSortDir * (a.count - b.count);
      return 0;
    });

    // Paginate
    const totalPages = Math.ceil(data.length / catPerPage);
    const start = (catPage - 1) * catPerPage;
    const page = data.slice(start, start + catPerPage);

    tbody.innerHTML = page.map((c, i) => {
      const share = ((c.count / total) * 100).toFixed(1);
      const barW  = Math.round((c.count / PLAYSTORE_DATA.categories[0].count) * 120);
      return `<tr style="animation:fadeUp 0.3s ease ${i * 0.04}s both">
        <td style="color:var(--text3)">${start + i + 1}</td>
        <td style="font-weight:500">${c.name.replace(/_/g, ' ')}</td>
        <td style="font-weight:700;color:var(--accent1)">${c.count.toLocaleString()}</td>
        <td>
          <span style="color:var(--text2)">${share}%</span>
          <span class="share-bar" style="width:${barW}px"></span>
        </td>
      </tr>`;
    }).join('');

    // Pagination info
    const info = document.getElementById('paginationInfo');
    if (info) info.textContent = `Showing ${start + 1}–${Math.min(start + catPerPage, data.length)} of ${data.length}`;

    // Pagination buttons
    const ctrl = document.getElementById('paginationControls');
    if (ctrl) {
      ctrl.innerHTML = '';
      const makeBtn = (label, page, active = false) => {
        const b = document.createElement('button');
        b.className = 'page-btn' + (active ? ' active' : '');
        b.textContent = label;
        b.onclick = () => { catPage = page; buildCategoryTable(filter); };
        ctrl.appendChild(b);
      };
      if (catPage > 1) makeBtn('‹', catPage - 1);
      for (let p = Math.max(1, catPage - 2); p <= Math.min(totalPages, catPage + 2); p++) {
        makeBtn(p, p, p === catPage);
      }
      if (catPage < totalPages) makeBtn('›', catPage + 1);
    }
  }

  buildCategoryTable();
  const catSearch = document.getElementById('catSearch');
  if (catSearch) {
    catSearch.addEventListener('input', () => { catPage = 1; buildCategoryTable(catSearch.value); });
  }

  // ---- Top Apps Grid ----
  const CATEGORY_ICONS = {
    COMMUNICATION: '💬', SOCIAL: '🌐', MAPS_AND_NAVIGATION: '🗺',
    VIDEO_PLAYERS: '▶️', GAME: '🎮', SHOPPING: '🛍', HEALTH_AND_FITNESS: '💪',
    TOOLS: '🔧', PRODUCTIVITY: '📋', EDUCATION: '📚',
  };

  function buildAppsGrid(apps) {
    const grid = document.getElementById('appsGrid');
    if (!grid) return;
    const data = apps || PLAYSTORE_DATA.topApps;
    grid.innerHTML = data.map((app, i) => {
      const fullStars = Math.floor(app.rating);
      const stars = Array.from({ length: 5 }, (_, s) =>
        `<span class="${s < fullStars ? 'star-fill' : 'star-empty'}">★</span>`).join('');
      const icon = CATEGORY_ICONS[app.category] || '📦';
      const bg = `background:rgba(${i % 2 === 0 ? '0,255,224' : '174,111,255'},0.08);border-color:rgba(${i % 2 === 0 ? '0,255,224' : '174,111,255'},0.15)`;
      return `
        <div class="app-card" style="animation-delay:${i * 0.06}s">
          <div class="app-rank">${String(i + 1).padStart(2, '0')}</div>
          <div class="app-header">
            <div class="app-icon" style="${bg}">${icon}</div>
            <div class="app-info">
              <div class="app-name">${app.name}</div>
              <div class="app-category">${app.category.replace(/_/g, ' ')}</div>
            </div>
          </div>
          <div class="app-divider"></div>
          <div class="app-meta">
            <div class="app-rating">
              <div class="stars">${stars}</div>
              ${app.rating}
            </div>
            <div class="app-installs">📥 ${app.installs}</div>
          </div>
        </div>`;
    }).join('');
  }
  buildAppsGrid();

  window.sortApps = function(key, btn) {
    document.querySelectorAll('.apps-toolbar .filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const sorted = [...PLAYSTORE_DATA.topApps].sort((a, b) => {
      if (key === 'rating') return b.rating - a.rating;
      if (key === 'name')   return a.name.localeCompare(b.name);
      return 0; // install count is already sorted by default
    });
    buildAppsGrid(sorted);
  };

  // ---- Filter Bar ----
  window.setFilter = function(btn, type) {
    document.querySelectorAll('.filter-bar .filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const labels = {
      all: 'All apps selected', free: 'Showing free apps only',
      paid: 'Showing paid apps only', top: 'Showing top-rated apps (4.5+)', games: 'Showing games only'
    };
    showToast('🔍 ' + (labels[type] || 'Filter applied'));
  };

  // ---- Data Explorer ----
  let explorerChartInstance = null;

  const EXPLORER_PALETTES = {
    neon:  ['#00ffe0','#ae6fff','#f5c400','#ff3e6c','#3d9aff','#26de81','#fd9644','#45aaf2','#a55eea','#fc5c65'],
    hot:   ['#ff3e6c','#ff6b35','#f5c400','#ff9ff3','#fd9644','#ff6348','#eb3b5a','#fa8231','#feca57','#ff5252'],
    cool:  ['#3d9aff','#00ffe0','#ae6fff','#45aaf2','#4ecdc4','#26de81','#2bcbba','#20bf6b','#54a0ff','#a55eea'],
    mono:  ['#dce8ff','#b0c4e0','#8a96a8','#6b80a0','#4d6080','#3d5070','#2d3d56','#1c2640','#141c2a','#0e1520'],
  };

  window.renderExplorer = function() {
    const type    = document.getElementById('explorerType')?.value || 'bar';
    const dataset = document.getElementById('explorerDataset')?.value || 'categories';
    const nVal    = document.getElementById('explorerN')?.value || '10';
    const colorKey= document.getElementById('explorerColor')?.value || 'neon';
    const palette = EXPLORER_PALETTES[colorKey];

    let labels, values, title;
    if (dataset === 'categories') {
      const n = nVal === 'all' ? PLAYSTORE_DATA.categories.length : parseInt(nVal);
      const data = PLAYSTORE_DATA.categories.slice(0, n);
      labels = data.map(c => c.name.replace(/_/g, ' '));
      values = data.map(c => c.count);
      title  = `Top ${n === PLAYSTORE_DATA.categories.length ? 'All' : n} Categories`;
    } else if (dataset === 'genres') {
      const n = nVal === 'all' ? PLAYSTORE_DATA.genres.length : parseInt(nVal);
      const data = PLAYSTORE_DATA.genres.slice(0, n);
      labels = data.map(g => g.name);
      values = data.map(g => g.count);
      title  = `Top ${n} Genres`;
    } else {
      labels = PLAYSTORE_DATA.ratingDist.labels;
      values = PLAYSTORE_DATA.ratingDist.values;
      title  = 'Rating Distribution';
    }

    const el = document.getElementById('explorerTitle');
    if (el) el.textContent = title;

    const ctx = document.getElementById('explorerChart');
    if (!ctx) return;
    if (explorerChartInstance) explorerChartInstance.destroy();

    const bgColors = palette.map(c => c + 'bb');
    const isCircular = type === 'doughnut' || type === 'pie';

    explorerChartInstance = new Chart(ctx, {
      type,
      data: {
        labels,
        datasets: [{
          label: 'Count',
          data: values,
          backgroundColor: isCircular ? bgColors : bgColors,
          borderColor: isCircular ? palette : palette[0],
          borderWidth: 1.5,
          borderRadius: isCircular ? 0 : 3,
          fill: type === 'line',
          tension: 0.4,
        }]
      },
      options: {
        ...CHART_DEFAULTS,
        cutout: type === 'doughnut' ? '60%' : undefined,
        scales: isCircular ? {} : CHART_DEFAULTS.scales,
        indexAxis: type === 'bar' && dataset !== 'ratings' ? undefined : undefined,
        plugins: {
          ...CHART_DEFAULTS.plugins,
          legend: { ...CHART_DEFAULTS.plugins.legend, display: isCircular, position: 'right' }
        },
        animation: { duration: 800 }
      }
    });
    showToast(`⚡ Chart generated: ${title}`);
  };

  // ---- Toast ----
  window.showToast = function(msg) {
    const container = document.getElementById('toast-container');
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    container.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  };

  // ---- Init Charts ----
  if (typeof initAllCharts === 'function') {
    setTimeout(initAllCharts, 120);
  }

});
