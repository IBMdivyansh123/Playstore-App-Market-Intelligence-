// ============================================================
//  PlayStore Analytics v2 — Dataset
// ============================================================

const PLAYSTORE_DATA = {

  totalApps: 10841,
  avgRating: 4.17,
  totalCategories: 33,
  freePercent: 92.6,
  paidPercent: 7.4,
  topGenresCount: 119,

  categories: [
    { name: "FAMILY",             count: 1972 },
    { name: "GAME",               count: 1144 },
    { name: "TOOLS",              count: 843  },
    { name: "MEDICAL",            count: 463  },
    { name: "BUSINESS",           count: 460  },
    { name: "PRODUCTIVITY",       count: 424  },
    { name: "PERSONALIZATION",    count: 392  },
    { name: "COMMUNICATION",      count: 387  },
    { name: "SPORTS",             count: 384  },
    { name: "LIFESTYLE",          count: 382  },
    { name: "FINANCE",            count: 366  },
    { name: "HEALTH_AND_FITNESS", count: 341  },
    { name: "PHOTOGRAPHY",        count: 335  },
    { name: "SOCIAL",             count: 295  },
    { name: "NEWS_AND_MAGAZINES", count: 283  },
    { name: "SHOPPING",          count: 260  },
    { name: "TRAVEL_AND_LOCAL",   count: 258  },
    { name: "DATING",             count: 234  },
    { name: "BOOKS_AND_REFERENCE",count: 231  },
    { name: "VIDEO_PLAYERS",      count: 175  },
    { name: "EDUCATION",          count: 156  },
    { name: "ENTERTAINMENT",      count: 149  },
    { name: "MAPS_AND_NAVIGATION",count: 137  },
    { name: "FOOD_AND_DRINK",     count: 127  },
    { name: "HOUSE_AND_HOME",     count: 88   },
    { name: "AUTO_AND_VEHICLES",  count: 85   },
    { name: "LIBRARIES_AND_DEMO", count: 85   },
    { name: "WEATHER",            count: 82   },
    { name: "ART_AND_DESIGN",     count: 65   },
    { name: "EVENTS",             count: 64   },
    { name: "COMICS",             count: 60   },
    { name: "PARENTING",          count: 60   },
    { name: "BEAUTY",             count: 53   },
  ],

  genres: [
    { name: "Tools",           count: 842 },
    { name: "Entertainment",   count: 623 },
    { name: "Education",       count: 549 },
    { name: "Medical",         count: 463 },
    { name: "Business",        count: 460 },
    { name: "Productivity",    count: 424 },
    { name: "Sports",          count: 398 },
    { name: "Personalization", count: 392 },
    { name: "Communication",   count: 387 },
    { name: "Lifestyle",       count: 381 },
    { name: "Finance",         count: 345 },
    { name: "Health & Fitness",count: 288 },
    { name: "Photography",     count: 281 },
    { name: "Social",          count: 239 },
    { name: "Shopping",        count: 202 },
  ],

  freePaid: { Free: 10038, Paid: 803 },

  ratingDist: {
    labels: ["1.0–2.0","2.0–3.0","3.0–3.5","3.5–4.0","4.0–4.2","4.2–4.4","4.4–4.6","4.6–5.0"],
    values: [42, 168, 412, 1204, 2388, 3102, 2104, 1421],
  },

  ratingLine: {
    labels: [1.0,1.5,2.0,2.5,3.0,3.5,4.0,4.1,4.2,4.3,4.4,4.5,4.6,4.7,4.8,4.9,5.0],
    values: [8,  18, 50, 120,310,740,1680,1900,2200,2800,2500,2100,1800,1200,600,220,80],
  },

  topApps: [
    { name: "WhatsApp Messenger",  category: "COMMUNICATION",      rating: 4.4, installs: "1,000,000,000+" },
    { name: "Facebook",            category: "SOCIAL",              rating: 4.1, installs: "1,000,000,000+" },
    { name: "Instagram",           category: "SOCIAL",              rating: 4.5, installs: "1,000,000,000+" },
    { name: "Google Maps",         category: "MAPS_AND_NAVIGATION", rating: 4.4, installs: "1,000,000,000+" },
    { name: "YouTube",             category: "VIDEO_PLAYERS",       rating: 4.3, installs: "1,000,000,000+" },
    { name: "Gmail",               category: "COMMUNICATION",       rating: 4.3, installs: "1,000,000,000+" },
    { name: "Google Play Games",   category: "GAME",                rating: 4.4, installs: "1,000,000,000+" },
    { name: "Subway Surfers",      category: "GAME",                rating: 4.5, installs: "1,000,000,000+" },
    { name: "Snapchat",            category: "SOCIAL",              rating: 4.0, installs: "500,000,000+"   },
    { name: "Clash of Clans",      category: "GAME",                rating: 4.6, installs: "500,000,000+"   },
  ],
};
