// ============================================================
//  PlayStore Analytics v2 — Chart Initializations (Chart.js v4)
// ============================================================

const CHART_DEFAULTS = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      labels: {
        color: '#6b80a0',
        font: { family: "'DM Mono', monospace", size: 11 },
        padding: 16,
        usePointStyle: true,
        pointStyleWidth: 8,
      }
    },
    tooltip: {
      backgroundColor: '#090e18',
      borderColor: '#28385a',
      borderWidth: 1,
      titleColor: '#dce8ff',
      bodyColor: '#6b80a0',
      titleFont: { family: "'DM Mono', monospace", size: 11 },
      bodyFont:  { family: "'DM Mono', monospace", size: 11 },
      padding: 12,
      cornerRadius: 6,
      displayColors: true,
      callbacks: {
        label: ctx => ` ${ctx.parsed.y !== undefined ? ctx.parsed.y.toLocaleString() : ctx.parsed.toLocaleString()}`
      }
    }
  },
  scales: {
    x: {
      ticks: { color: '#6b80a0', font: { family: "'DM Mono', monospace", size: 10 } },
      grid:  { color: 'rgba(255,255,255,0.04)' },
      border:{ color: '#1c2640' },
    },
    y: {
      ticks: { color: '#6b80a0', font: { family: "'DM Mono', monospace", size: 10 } },
      grid:  { color: 'rgba(255,255,255,0.04)' },
      border:{ color: '#1c2640' },
    }
  }
};

function neonPalette(n) {
  const cols = [
    '#00ffe0','#ae6fff','#f5c400','#ff3e6c','#3d9aff',
    '#26de81','#fd9644','#45aaf2','#a55eea','#fc5c65',
    '#2bcbba','#20bf6b','#eb3b5a','#fa8231','#8854d0',
    '#feca57','#ff6348','#54a0ff','#00cec9','#e17055',
  ];
  return Array.from({ length: n }, (_, i) => cols[i % cols.length]);
}

// --- 1. Category Bar Chart ---
function initCategoryBarChart() {
  const ctx = document.getElementById('categoryBarChart');
  if (!ctx) return;
  const top10 = PLAYSTORE_DATA.categories.slice(0, 10);
  const palette = neonPalette(10);

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: top10.map(c => c.name.replace(/_/g, ' ')),
      datasets: [{
        label: 'App Count',
        data: top10.map(c => c.count),
        backgroundColor: palette.map(c => c + '99'),
        borderColor: palette,
        borderWidth: 1.5,
        borderRadius: 4,
        borderSkipped: false,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: { ...CHART_DEFAULTS.plugins, legend: { display: false } },
      scales: {
        ...CHART_DEFAULTS.scales,
        x: {
          ...CHART_DEFAULTS.scales.x,
          ticks: { ...CHART_DEFAULTS.scales.x.ticks, maxRotation: 30 }
        }
      },
      animation: { duration: 1000, easing: 'easeOutQuart' }
    }
  });
}

// --- 2. Free vs Paid Doughnut ---
function initFreePaidChart() {
  const ctx = document.getElementById('freePaidChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Free', 'Paid'],
      datasets: [{
        data: [PLAYSTORE_DATA.freePaid.Free, PLAYSTORE_DATA.freePaid.Paid],
        backgroundColor: ['#00ffe099', '#ff3e6c99'],
        borderColor: ['#00ffe0', '#ff3e6c'],
        borderWidth: 2,
        hoverOffset: 10,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      cutout: '68%',
      scales: {},
      animation: { animateRotate: true, duration: 1400 },
      plugins: {
        ...CHART_DEFAULTS.plugins,
        legend: { ...CHART_DEFAULTS.plugins.legend, position: 'bottom' },
        tooltip: {
          ...CHART_DEFAULTS.plugins.tooltip,
          callbacks: {
            label: ctx => ` ${ctx.label}: ${ctx.parsed.toLocaleString()} apps`
          }
        }
      }
    }
  });
}

// --- 3. Rating Distribution Bar ---
function initRatingDistChart() {
  const ctx = document.getElementById('ratingDistChart');
  if (!ctx) return;
  const { labels, values } = PLAYSTORE_DATA.ratingDist;

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Apps',
        data: values,
        backgroundColor: values.map((_, i) => {
          const pct = i / (values.length - 1);
          return `hsla(${170 + pct * 60}, 90%, 60%, 0.75)`;
        }),
        borderRadius: 4,
        borderSkipped: false,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: { ...CHART_DEFAULTS.plugins, legend: { display: false } },
      animation: { duration: 900 }
    }
  });
}

// --- 4. All Categories Horizontal Bar ---
function initAllCategoriesChart() {
  const ctx = document.getElementById('allCategoriesChart');
  if (!ctx) return;
  const cats = PLAYSTORE_DATA.categories.filter(c => c.name !== '1.9');

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: cats.map(c => c.name.replace(/_/g, ' ')),
      datasets: [{
        label: 'Apps',
        data: cats.map(c => c.count),
        backgroundColor: '#00ffe055',
        borderColor: '#00ffe0',
        borderWidth: 1.5,
        borderRadius: 3,
        borderSkipped: false,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      indexAxis: 'y',
      plugins: { ...CHART_DEFAULTS.plugins, legend: { display: false } },
      scales: {
        x: { ...CHART_DEFAULTS.scales.x },
        y: {
          ...CHART_DEFAULTS.scales.y,
          ticks: {
            color: '#6b80a0',
            font: { family: "'DM Mono', monospace", size: 10 },
            padding: 8
          },
        }
      },
      animation: { duration: 1200 }
    }
  });
}

// --- 5. Genre Bar Chart ---
function initGenreBarChart() {
  const ctx = document.getElementById('genreBarChart');
  if (!ctx) return;
  const top15 = PLAYSTORE_DATA.genres.slice(0, 15);
  const palette = neonPalette(15);

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: top15.map(g => g.name),
      datasets: [{
        label: 'App Count',
        data: top15.map(g => g.count),
        backgroundColor: palette.map(c => c + '99'),
        borderColor: palette,
        borderWidth: 1.5,
        borderRadius: 4,
        borderSkipped: false,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: { ...CHART_DEFAULTS.plugins, legend: { display: false } },
      scales: {
        ...CHART_DEFAULTS.scales,
        x: { ...CHART_DEFAULTS.scales.x, ticks: { ...CHART_DEFAULTS.scales.x.ticks, maxRotation: 40 } }
      },
      animation: { duration: 1000 }
    }
  });
}

// --- 6. Genre Pie Chart ---
function initGenrePieChart() {
  const ctx = document.getElementById('genrePieChart');
  if (!ctx) return;
  const top8 = PLAYSTORE_DATA.genres.slice(0, 8);
  const palette = neonPalette(8);

  new Chart(ctx, {
    type: 'pie',
    data: {
      labels: top8.map(g => g.name),
      datasets: [{
        data: top8.map(g => g.count),
        backgroundColor: palette.map(c => c + '99'),
        borderColor: palette,
        borderWidth: 2,
        hoverOffset: 10,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      scales: {},
      animation: { animateRotate: true, duration: 1400 },
      plugins: {
        ...CHART_DEFAULTS.plugins,
        legend: { ...CHART_DEFAULTS.plugins.legend, position: 'right' }
      }
    }
  });
}

// --- 7. Rating KDE Line Chart ---
function initRatingLineChart() {
  const ctx = document.getElementById('ratingLineChart');
  if (!ctx) return;
  const { labels, values } = PLAYSTORE_DATA.ratingLine;

  const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 300);
  gradient.addColorStop(0, 'rgba(0,255,224,0.28)');
  gradient.addColorStop(1, 'rgba(0,255,224,0.00)');

  new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'App Density',
        data: values,
        borderColor: '#00ffe0',
        backgroundColor: gradient,
        borderWidth: 2.5,
        fill: true,
        tension: 0.5,
        pointRadius: 4,
        pointHoverRadius: 7,
        pointBackgroundColor: '#00ffe0',
        pointBorderColor: '#04070d',
        pointBorderWidth: 2,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: {
        ...CHART_DEFAULTS.plugins,
        legend: { display: false },
        tooltip: {
          ...CHART_DEFAULTS.plugins.tooltip,
          callbacks: {
            label: ctx => ` ${ctx.parsed.y.toLocaleString()} apps near rating ${ctx.label}`
          }
        }
      },
      animation: { duration: 1200 }
    }
  });
}

// ---- Export ----
window.initAllCharts = function() {
  initCategoryBarChart();
  initFreePaidChart();
  initRatingDistChart();
  initAllCategoriesChart();
  initGenreBarChart();
  initGenrePieChart();
  initRatingLineChart();
};
